﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using OdemeTakip.Data;

namespace OdemeTakip.Desktop
{
    public partial class App : Application
    {
        public static AppDbContext DbContext { get; private set; } = null!;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            string localConnection = "Server=192.168.1.75,1434;Database=OdemeTakip;User Id=sa;Password=Yeksun.1288;TrustServerCertificate=True";
            string vpnConnection = "Server=10.0.0.1,1434;Database=OdemeTakip;User Id=sa;Password=Yeksun.1288;TrustServerCertificate=True";

            string selectedConnection;

            if (TestSqlConnection(localConnection))
            {
                selectedConnection = localConnection;
                MessageBox.Show("Ofiste olduğunuz için yerel mod aktif edildi.", "Bağlantı Algılandı", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                selectedConnection = vpnConnection;
                MessageBox.Show("Ofis dışında olduğunuz için VPN modu aktif edildi.", "Bağlantı Algılandı", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(selectedConnection)
                .Options;

            DbContext = new AppDbContext(options);

            var mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private bool TestSqlConnection(string connectionString)
        {
            try
            {
                // Timeout parametresi ekle
                var builder = new SqlConnectionStringBuilder(connectionString)
                {
                    ConnectTimeout = 3 // saniye
                };

                using var connection = new SqlConnection(builder.ConnectionString);
                connection.Open();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
