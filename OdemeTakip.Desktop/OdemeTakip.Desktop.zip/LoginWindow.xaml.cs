﻿using System.Windows;

namespace OdemeTakip.Desktop
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(UsernameTextBox.Text) || string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                MessageBox.Show("Username and password must not be empty.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Test login (gerçek kontrol yok)
            if (UsernameTextBox.Text == "admin" && PasswordBox.Password == "1234")
            {
                this.DialogResult = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Incorrect username or password.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
