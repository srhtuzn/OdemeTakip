﻿using System;
using System.Linq;
using System.Windows;
using OdemeTakip.Data;
using OdemeTakip.Entities;
using OdemeTakip.Desktop.Helpers;

namespace OdemeTakip.Desktop
{
    public partial class KrediKartiHarcamaForm : Window
    {
        private readonly AppDbContext _db;
        private readonly KrediKartiHarcama _harcama;
        private readonly bool _isEdit;

        public KrediKartiHarcamaForm(AppDbContext db, KrediKarti seciliKart, KrediKartiHarcama? harcama = null)

        {
            InitializeComponent();
            _db = db;
            _harcama = harcama ?? new KrediKartiHarcama();
            _isEdit = harcama != null;

            YukleKartlar();

            if (_isEdit)
                FormuDoldur();
            else
                dpHarcamaTarihi.SelectedDate = DateTime.Today;
        }

        private void YukleKartlar()
        {
            cmbKrediKartlari.ItemsSource = _db.KrediKartlari.Where(k => k.IsActive).ToList();
        }

        private void FormuDoldur()
        {
            cmbKrediKartlari.SelectedValue = _harcama.KrediKartiId;
            txtAciklama.Text = _harcama.Aciklama;
            txtTutar.Text = _harcama.Tutar.ToString("N2");
            txtTaksitSayisi.Text = _harcama.TaksitSayisi.ToString();
            dpHarcamaTarihi.SelectedDate = _harcama.HarcamaTarihi;
        }

        private void BtnKaydet_Click(object sender, RoutedEventArgs e)
        {
            if (cmbKrediKartlari.SelectedValue is not int krediKartiId)
            {
                MessageBox.Show("Lütfen bir kart seçin.");
                return;
            }

            if (!decimal.TryParse(txtTutar.Text, out decimal tutar) || tutar <= 0)
            {
                MessageBox.Show("Geçerli bir tutar girin.");
                return;
            }

            if (!int.TryParse(txtTaksitSayisi.Text, out int taksitSayisi) || taksitSayisi < 1)
            {
                MessageBox.Show("Taksit sayısı 1 veya daha büyük olmalı.");
                return;
            }

            if (dpHarcamaTarihi.SelectedDate == null)
            {
                MessageBox.Show("Lütfen harcama tarihini seçin.");
                return;
            }

            if (_isEdit)
            {
                // Düzenleme modunda sadece harcama güncellenir
                _harcama.KrediKartiId = krediKartiId;
                _harcama.Aciklama = txtAciklama.Text.Trim();
                _harcama.Tutar = tutar;
                _harcama.TaksitSayisi = taksitSayisi;
                _harcama.HarcamaTarihi = dpHarcamaTarihi.SelectedDate.Value;
                _db.SaveChanges();
            }
            else
            {
                // Yeni kayıt modunda hem harcama hem taksitler oluşturulur
                try
                {
                    KrediKartiHarcamaHelper.HarcamaEkle(_db, krediKartiId, tutar, txtAciklama.Text.Trim(), taksitSayisi, dpHarcamaTarihi.SelectedDate.Value);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Harcama kaydı yapılamadı.\n{ex.Message}");
                    return;
                }
            }

            DialogResult = true;
            Close();
        }

        private void BtnIptal_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
