﻿namespace OdemeTakip.Data
{
    public class Class1
    {

    }
}
