﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdemeTakip.Entities
{
    public class User
    {
        public int Id { get; set; }
        public string? Username { get; set; }       // Giriş kullanıcı adı
        public string? PasswordHash { get; set; }   // Hashlenmiş şifre
        public string? Role { get; set; }           // Admin, Kullanıcı
    }
}
