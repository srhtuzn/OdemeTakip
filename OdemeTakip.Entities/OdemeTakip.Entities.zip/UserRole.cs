﻿namespace OdemeTakip.Entities // veya projenize uygun bir namespace
{
    public enum UserRole
    {
        Personnel = 0, // Normal Personel
        Admin = 1      // Yönetici
    }
}